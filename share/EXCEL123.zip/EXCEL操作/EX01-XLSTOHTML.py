import pandas as pd
import openpyxl

def excel_to_html(excel_file_path, html_file_path):
    # 读取 Excel 文件
    excel_data = pd.read_excel(excel_file_path, engine='openpyxl')

    # 将 DataFrame 转换为 HTML 表格
    html_table = excel_data.to_html(index=False) # index=False 表示不显示行索引

    # 写入 HTML 文件
    with open(html_file_path, 'w', encoding='utf-8') as file:
        file.write(html_table)

# 使用方法

# 读取Excel文件并转换为HTML表格
def excel_to_html_table_merge(excel_file_path, html_file_path):
    wb = openpyxl.load_workbook(excel_file_path,data_only=True)
    sheet = wb.active
    merged_cells=[]
    # 转换合并单元格
    for cell in sheet.merged_cells:
        oneinfo =cell.min_row, cell.min_col,cell.size
        merged_cells.append(oneinfo)

    html_table = '<table class="table table-bordered">'  
    for row in sheet.iter_rows(values_only=False):
        html_table += '<tr>'
        for cell in row:
            if cell.coordinate in sheet.merged_cells:
                    for m in merged_cells:
                        if(sheet.cell(row=m[0], column=m[1]).value== cell.value):    
                            html_table += f'<td colspan="{m[2]["columns"]}" rowspan="{m[2]["rows"]}">{cell.value}</td>'
                            merged_cells.remove(m)
            else:
                if cell.value is None:
                    html_table += f'<td></td>'
                else:
                    html_table += f'<td>{cell.value}</td>'
        html_table += '</tr>'
    html_table += '</table>'
    
    htmlall = f' <link href="https://cdn.staticfile.net/twitter-bootstrap/5.1.1/css/bootstrap.min.css" rel="stylesheet"> \
                 <script src="https://cdn.staticfile.net/twitter-bootstrap/5.1.1/js/bootstrap.bundle.min.js"></script><html>{html_table}</html>'
    with open(html_file_path, 'w', encoding='utf-8') as file:
        file.write(htmlall)

def main():
    excel_file = '附1-2.2021年3月份鸟类同步调查数据汇总表.xlsx'
    html_file = '附1-2.2021年3月份鸟类同步调查数据汇总表_merge.html'
    #excel_to_html(excel_file, html_file)
    excel_to_html_table_merge(excel_file, html_file)

if __name__ == '__main__':
    main()
